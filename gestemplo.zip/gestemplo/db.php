<?php
// Informações de Conexão com banco de dados MySQL > 5.0

define("EW_CONN_HOST", 'localhost', TRUE);
define("EW_CONN_PORT",'', TRUE);
define("EW_CONN_USER", 'scriptph_script', TRUE);
define("EW_CONN_PASS", '@script2323', TRUE);
define("EW_CONN_DB", 'scriptph_gestemplo', TRUE);


?>
